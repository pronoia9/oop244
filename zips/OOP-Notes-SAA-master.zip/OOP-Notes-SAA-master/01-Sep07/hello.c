#include <stdio.h>
void print(int a) {
   printf("%d", a);
}
int main() {
   int n;
   n = printf("Wassssssssssssssup?\n");
   print(n);
   return 0;
}