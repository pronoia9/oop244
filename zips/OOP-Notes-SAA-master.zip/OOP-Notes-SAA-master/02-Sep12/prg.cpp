#include <iostream>
using namespace std;
int main() {
   int i = 10;
   int j = 20;
   bool a = i > j;
   int k = i > j;
   double d = 12.3434;
   cout << k << endl << "Hello there" << endl << d << endl;
   return 0;
}