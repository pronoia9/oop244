#include <iostream>
using namespace std;
int main() {
   int i = 100;
   double d;
   cout << "this is what it is!" << endl;
   cout << i << endl;
   cout << "what the price? ";
   cin >> d;
   cout << "The price is " << d << endl;
   return 0;
}