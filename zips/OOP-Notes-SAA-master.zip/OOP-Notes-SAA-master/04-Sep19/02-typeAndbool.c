#include <iostream>
using namespace std;
struct Student {
   int stno;
   char name[41];
};
int main() {
   Student st;
   bool cond = true;
   cout << true << endl;
   return 0;
}