#ifndef ICT_STUDENT_H__
#define ICT_STUDENT_H__

class Student {

};



#endif