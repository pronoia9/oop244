//Header: employee.h //.5

#ifndef ICT_EMPlOYEE_H_ //1
#define ICT_EMPlOYEE_H_
class Employee { //1


};

#endif               //1

// cpp file employee.cpp //.5

#include "employee.h"//1


