// 5 marks
//Header: student.h //.5

#ifndef ICT_STUDENT_H_ //1
#define ICT_STUDENT_H_
class Student { //1


};

#endif               //1

// cpp file student.cpp //.5

#include "student.h"//1


