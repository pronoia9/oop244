#include <cstring>
#include <iostream>
#include "String.h"


using namespace std;

namespace ict
{
   // write your implementations here
}
