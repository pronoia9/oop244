/*Weather.cpp*/
//  includes go here

// ict namespace 
  // set method 

  // date method (query)

  // low method (query)
 
  // display

