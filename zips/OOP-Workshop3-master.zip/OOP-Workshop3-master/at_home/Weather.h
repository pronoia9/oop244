// compilation safegaurds

/*Weather.h*/

 // ict namespace
