


namespace ict {
	class Contact {
		char name_[41];
		PhoneNumber* phoneNumber_;
		int noPN_;
		void setEmpty();

	public:

		void read();		
		bool isEmpty()const;
	};

}
