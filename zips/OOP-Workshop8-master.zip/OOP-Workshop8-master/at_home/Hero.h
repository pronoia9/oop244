
class Hero{
};