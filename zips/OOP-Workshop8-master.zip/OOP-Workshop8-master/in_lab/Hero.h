
class Hero{



};

#endif