#ifndef SICT_DRIVER_H_
#define SICT_DRIVER_H_


namespace sict
{
	class Driver
	{
	private:
		// private members go here


	public:
		// public members go here


	};
}
#endif