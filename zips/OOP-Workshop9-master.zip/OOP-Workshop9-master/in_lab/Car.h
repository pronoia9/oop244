#ifndef SICT_CAR_H_
#define SICT_CAR_H_

namespace sict
{
	// complete the declaration of the class
	class Car
	{
	private:
		// private members go here


	protected:
		// protected members go here


	public:
		// public members go here


	};
}

#endif