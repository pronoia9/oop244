#include "PickupTruck.h"

namespace sict
{



}