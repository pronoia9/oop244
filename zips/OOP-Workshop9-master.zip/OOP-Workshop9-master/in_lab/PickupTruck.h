#ifndef SICT_TRUCK_H_
#define SICT_TRUCK_H_


namespace sict
{
	// complete the declaration of the class
	class PickupTruck
	{
	private:
		// private members go here


	public:
		// public members go here


		// pure virtual members from base class go here


	};
}
#endif