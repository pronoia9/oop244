#ifndef SICT_SPORTCAR_H_
#define SICT_SPORTCAR_H_

namespace sict
{
	// complete the declaration of the class
	class SportCar
	{
	private:
		// private members go here


	public:
		// public members go here


		// pure virtual members from base class go here


	};
}
#endif