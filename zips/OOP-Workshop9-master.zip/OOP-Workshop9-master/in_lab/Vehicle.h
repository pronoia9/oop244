#ifndef SICT_VEHICLE_
#define SICT_VEHICLE_

namespace sict
{
	// complete the declaration of the class
	class Vehicle
	{
	public:
		// public members go here


	};
}
#endif