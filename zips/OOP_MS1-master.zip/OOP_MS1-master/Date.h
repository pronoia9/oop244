#ifndef ICT_DATE_H__
#define ICT_DATE_H__
// header file includes


namespace ict {
   // Error code values go here



   class Date {
   private:
      // private member variables

      // private member functions and setters

      int value()const;

   public:
      // constructors


      // operator overloads


      // IO member functions

      // public member functions and getters
      int mdays()const;
   };
   // operator << and >> overloads prototypes for ostream and istream go here
}
#endif
