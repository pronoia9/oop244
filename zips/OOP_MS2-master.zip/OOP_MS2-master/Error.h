#ifndef SICT_ERROR_H__
#define SICT_ERROR_H__
#include <iostream>
namespace ict{
  class Error{

  public:

  };
  // operator<< overload prototype
}
#endif

