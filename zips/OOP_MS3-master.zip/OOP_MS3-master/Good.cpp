#include <cstring>
#include <iostream>
#include "wpgeneral.h"
#include "Good.h"
using namespace std;
namespace ict{



}