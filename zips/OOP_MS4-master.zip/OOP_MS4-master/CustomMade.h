#ifndef ICT_CUSTOMMADE_H__
#define ICT_CUSTOMMADE_H__
#include "OnShelf.h"
#include "Date.h"
#include "Error.h"
namespace ict {
   class CustomMade :??????{
   private:
   public:
      void delivery(const Date &value);
   };
}


#endif
