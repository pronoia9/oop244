#ifndef ICT_ONSHELF_H__
#define ICT_ONSHELF_H__
#include "Good.h"
#include "Error.h"
namespace ict {
   class OnShelf : ??????{
   private:
   protected:
   public:
   };
}
#endif