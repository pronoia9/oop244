#define _CRT_SECURE_NO_WARNINGS
#include <cstring>
#include <iomanip>
#include "WPlanner.h"
#include "Good.h"
#include "OnShelf.h"
#include "CustomMade.h"

using namespace std;
namespace ict {

   WPlanner::WPlanner(const char* filename) {



   }
   void WPlanner::saveRecs() {




   }
   void WPlanner::loadRecs() {




   }
   void WPlanner::getSku(char* sku) {




   }
   void WPlanner::deleteItem() {
      cout << "Not implemented!" << endl << endl;





   }
   void WPlanner::updateQty() {










   }
   void WPlanner::listItems()const {


      cout << " Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery" << endl
         << "-----|-----|--------------------|-------|---|----|----|----------" << endl;




      cout << "-----+-----+--------------------+-------+---+----+----+----------" << endl;





   }
   int WPlanner::SearchItems(const char* sku)const {







   }
   void WPlanner::addItem(bool isCustomMade) {






   }
   int WPlanner::menu() {
      int selection = -1;












      return selection;
   }
   int WPlanner::run() {
      bool done = false;
      while (!done) {
         switch () {
         case 1:

            break;
         case 2:


            break;
         case 3:


            break;
         case 4:


            break;
         case 5:

            break;
         case 0:
            done = true;
            cout << "Goodbye!!" << endl << endl;
            break;
         case -1:
            cout << "===Invalid Selection, try again.===" << endl <<endl ;
            break;
         }
      }
      return 0;
   } // WPlanner::run() end
}


/* outputs

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
>



Not found!

Please enter the number of purchased goods:

Too many purchased, only 5 needed, please return the extra 15.

Updated!

Not implemented!

*/