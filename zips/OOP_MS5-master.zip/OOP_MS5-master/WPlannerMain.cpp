#include "WPlanner.h"
int main(){
  ict::WPlanner app("WPlanner.txt");
  return app.run();
}

/*
oop_ms5_short output:
Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $3397.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: 789
Name: Fruit
Price: 200
Taxed: n
Quantity On hand: 0
Quantity Needed: 1

Good added

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: 890
Name: Cake
Price: 500
Taxed: y
Quantity On hand: 0
Quantity Needed: 1
delivery date (YYYY/MM/DD) : 2017/10/20

Good added

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 4

Please enter the SKU: 123

Sku: 123
Name: Centerpiece
Price: 120.55
Price after tax: 136.22
Quantity On Hand: 5
Quantity Needed: 20

Please enter the number of purchased goods: 10

Updated!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |  15|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
   7 | 789 |Fruit               | 200.00|   |   0|   1|
   8 | 890 |Cake                | 565.00| t |   0|   1|2017/10/20
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $4760.07

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 0

Goodbye!!




*/


/*

MS5 Long output



Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $3397.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: abc
Name: abc
Price: abc

Invalid Price Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: abc
Name: abc
Price: 10
Taxed: abc

Only (Y)es or (N)o are acceptable

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: abc
Name: abc
Price: 10
Taxed: y
Quantity On hand: abc

Invalid Quantity Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: abc
Name: abc
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: abc

Invalid Quantity Needed Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 2

Sku: abc
Name: abc
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10

Good added

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: qwe
Name: qwe
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10
delivery date (YYYY/MM/DD) : abc

Invalid Date Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: qwe
Name: qwe
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10
delivery date (YYYY/MM/DD) : 20/20/20

Invalid Year in Date Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: qwe
Name: qwe
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10
delivery date (YYYY/MM/DD) : 2017/20/20

Invalid Month in Date Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: qwe
Name: qwe
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10
delivery date (YYYY/MM/DD) : 2017/10/50

Invalid Day in Date Entry

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 3

Sku: qwe
Name: qwe
Price: 10
Taxed: y
Quantity On hand: 10
Quantity Needed: 10
delivery date (YYYY/MM/DD) : 2017/10/10

Good added

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 4

Please enter the SKU: abc

Sku: abc
Name: abc
Price: 10.00
Price after tax: 11.30
Quantity On Hand: 10
Quantity Needed: 10

Please enter the number of purchased goods: abc
Invalid Quantity value!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 4

Please enter the SKU: abc

Sku: abc
Name: abc
Price: 10.00
Price after tax: 11.30
Quantity On Hand: 10
Quantity Needed: 10

Please enter the number of purchased goods: 50

Too many purchased, only 0 needed, please return the extra 50.

Updated!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
   7 | abc |abc                 |  11.30| t |  10|  10|
   8 | qwe |qwe                 |  11.30| t |  10|  10|2017/10/10
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $3623.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 4

Please enter the SKU: 345

Sku: 345
Name: Four course dinner
Price: 85.00
Price after tax: 96.05
Quantity On Hand: 0
Quantity Needed: 160

Please enter the number of purchased goods: 100

Updated!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t | 100| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
   7 | abc |abc                 |  11.30| t |  10|  10|
   8 | qwe |qwe                 |  11.30| t |  10|  10|2017/10/10
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $13228.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 0

Goodbye!!

*/


/*
Bonus output

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $3397.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 5

Please enter the SKU: 234

The following Item will be deleted:
Sku: 234
Name: DJ
Price: 600.00
Price after tax: 678.00
Quantity On Hand: 0
Quantity Needed: 1

Type (Y) to confirm or (N) to abort: n

Aborted!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 234 |DJ                  | 678.00| t |   0|   1|
   3 | 345 |Four course dinner  |  96.05| t |   0| 160|
   4 | 456 |Bridal Gown         |2260.00| t |   1|   1|2017/10/10
   5 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   6 | 678 |Bottled Water       |   0.55|   |  60| 200|
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $3397.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 5

Please enter the SKU: 234

The following Item will be deleted:
Sku: 234
Name: DJ
Price: 600.00
Price after tax: 678.00
Quantity On Hand: 0
Quantity Needed: 1

Type (Y) to confirm or (N) to abort: y

Item deleted!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 5

Please enter the SKU: 456

The following Item will be deleted:
Sku: 456
Name: Bridal Gown
Price: 2000.00
Price after tax: 2260.00
Quantity On Hand: 1
Quantity Needed: 1
delivery date: 2017/10/10

Type (Y) to confirm or (N) to abort: y

Item deleted!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 5

Please enter the SKU: 456

Item Not found!

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 1

 Row | SKU | Good Name          | Cost  |Tax| QTY|Need| Delivery
-----|-----|--------------------|-------|---|----|----|----------
   1 | 123 |Centerpiece         | 136.22| t |   5|  20|
   2 | 345 |Four course dinner  |  96.05| t |   0| 160|
   3 | 567 |Chair shashes       |  16.95| t |  25| 160|2017/10/12
   4 | 678 |Bottled Water       |   0.55|   |  60| 200|
-----+-----+--------------------+-------+---+----+----+----------
Total cost of the Wedding: $1137.86

Wedding Planner Management Program
1 - List goods
2 - Add On Shelf Good
3 - Add Custom-Made Good
4 - Update Good quantity
5 - Delete
0 - Exit program
> 0

Goodbye!!


*/